#include <iostream>
#include "OrderQueue.h"
using namespace std;


class OrderQueue
{
	public:
		OrderQueue();
		void addOrderToQueue(Order* order);
		void removeOrderFromQueue();
		Order& getFirstOrder ();
		bool empty;
		void printAllOrders();
	private:
		Order* head;
		Order* tail;	
		
};


int main (){}
