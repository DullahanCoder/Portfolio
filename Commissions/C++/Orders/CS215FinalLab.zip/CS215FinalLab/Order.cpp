#include <iostream>
#include "Order.h"
using namespace std;

class Order 
{
	public:
		Order (int number, string name);
		string getCustomerName();
		void printOrder();
		friend class OrderQueue;
		~Order();
	private:
		Order* next_order;
		Order* prev_order;
		int* number;
		string* name;	
};

int main ()
{
	cout<<"hello";
}
